const mongoose = require("mongoose");

const articleSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  description: {
    type: String,
    required: true,
  },
  filename: {
    type: String,
    // required: true,
  },
  completed: {
    type: Boolean,
    default: false,
  },
});

const Todofile = mongoose.model("Todofile", articleSchema);

module.exports = Todofile;
