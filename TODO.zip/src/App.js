// import CarSell from './components/Carsell';
// import Add from './components/practice/create';
import Appi from './components/TODOApp';
import {React} from 'react'
// import ParentoComponento from './components/practice/useCallback';
// import ParentComponent from './components/propsdrilling';
// import ExpensiveComponent from './components/practice/useit'
import './App.css';


function App() {
  return (
    <div className="App">
  {/* <CarSell /> */}
         {/* <Add />  */}
       {/* <ParentComponent />
       <ParentoComponento />
       <ExpensiveComponent /> */}
       <Appi />
    </div>
  );
}

export default App;



























    