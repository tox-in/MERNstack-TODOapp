import React, { useState, useEffect } from "react";
import './TODOApp.css'
import axios from "axios";
import Clock from "./Todochildtime";

const Appi = () => {
  const [articles, setArticles] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");


  useEffect(() => {
    fetchArticles();
  }, []);

  const fetchArticles = async () => {
    try {
      const response = await axios.get("http://localhost:3001/todo");
      setArticles(response.data);
    } catch (err) {
      console.error(err);
    }
  };


  const deleteArticle = async (articleId) => {
    try {
      await axios.delete(`http://localhost:3001/todo/${articleId}`);
      fetchArticles();
    } catch (err) {
      console.error(err);
    }
  };

  const updateArticle = async (articleId) => {
    try {
      await axios.put(`http://localhost:3001/todo/${articleId}`,
       {
        completed : true
       }
      );
      fetchArticles();
    } catch (err) {
      console.error(err);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const formData = new FormData();
      formData.append("title", title);
      formData.append("description", description);

      const {data} = await axios.post('http://localhost:3001/todo', {
        title,
        description
      })

      setTitle("");
      setDescription("");
      fetchArticles();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className="container position-sticky" >
      <div className="position-sticky">
      <h1 class="h1 text-decoration-underline text-primary fst-italic">MERN Stack TODO App</h1>
      <Clock />
      <div className="row g-9 align-items-center ">
        <h2 className="text-decoration-underline fst-normal">Add Todo</h2>
      <form onSubmit={handleSubmit} className="row g-3">
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          class="form-control"
          id="title"
          required
        />
        <br />
        <input
          type="time"
          placeholder="Time"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="form-control form-control-md"
          class="form-control"
          id="description"
          required
        />
        <br />
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
      </div>
      </div>
      <div class="todo-list position-absolute top-20 start-20">
      <h2 className="todos text-decoration-underline">Todos:</h2>
      <ul className="list-group" >
        {articles.map((article) => (
          <li  style={article.completed? {textDecoration: "line-through"} : {textDecoration:""}} className="list-group-item" key={article._id}>
            <h3>{article.title}</h3>
            <p>{article.description}</p>
            <button onClick={() => deleteArticle(article._id)} className="btn btn-danger">Delete</button>
            <button onClick={() => updateArticle(article._id)}   className={`btn ${article.completed ? 'btn-secondary' : 'btn-success'}`}> {article.completed ? 'Completed' : 'Complete'}</button>
          </li>
        ))} 
      </ul>
      </div>
      <div className="completed-uncompleted position-absolute top-20 start-50 translate-middle-x ">
      <h2 className="text-decoration-underline">Uncompleted:</h2>
      <ul className="list-group">
      {articles.map((article) => (
          <li style={article.completed? {display: "none"}: {display: "block"}} className="list-group-item"  key={article._id}>
            <h3>{article.title}</h3>
            <p>{article.description}</p>
            <button onClick={() => deleteArticle(article._id)} className="btn btn-danger w-60">Delete</button>
            <button onClick={() => updateArticle(article._id)} className="btn btn-success" >Done</button>
          </li>
        ))} 
      </ul>
      </div>
      <div className="completed-uncompleted1 position-absolute top-20 end-0 ">
      <h2 className="text-decoration-underline" >Completed:</h2>
      <ul className="list-group">
      {articles.map((article) => (
          <li style={article.completed? {display: "block"}: {display: "none"}} className="list-group-item" key={article._id}>
            <h3>{article.title}</h3>
            <p>{article.description}</p>
            <button onClick={() => deleteArticle(article._id)}className="btn btn-danger">Delete</button>
          </li>
        ))} 
      </ul>
      </div>
      </div>
  );
};

export default Appi;
