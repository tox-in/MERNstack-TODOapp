const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const Todofile = require("./models/TodoCRUD.model");

// Create Express app
const app = express();
app.use(express.json());
app.use(cors());



// Mongoose connection
mongoose.connect("mongodb://127.0.0.1:27017/todo", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});
const db = mongoose.connection;
db.on("error", console.error.bind(console, "MongoDB connection error:"));
db.once("open", () => {
  console.log("Connected to MongoDB");
});

// Create a news article
app.post("/todo", async (req, res) => {
  try {
    const { title, description } = req.body;
    if (!req.body) return res.send({ message: "All data required!" });

    console.log(req.body)

    const newTodo = new Todofile({
      title,
      description
    });

    const savedTodo = await newTodo.save();

    res.status(201).json(savedTodo);
  } catch (err) {
    res.status(500).json({ error: "Failed to save article" });
  }
});

// Read all news articles
app.get("/todo", async (req, res) => {
  try {
    const todos = await Todofile.find({});
    res.json(todos);
  } catch (err) {
    res.status(500).json({ error: "Failed to retrieve articles" });
  }
});

// Read a specific news article
// app.get("/home/:id", async (req, res) => {
//   try {
//     const id = req.params.id;
//     const article = await NewsArticle.findById({id});

//     if (article) {
//       res.json(article);
//     } else {
//       res.status(404).json({ error: "Article not found" });
//     }
//   } catch (err) {
//     console.error(err);
//     res.status(500).json({ error: "Failed to retrieve article" });
//   }
// });

// Update a news article
app.put("/todo/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const completed = req.body;

    const updatedTodo = await Todofile.findByIdAndUpdate(
      id,
      completed , {
        new: true
      }
    )

    if (updatedTodo) {
      res.json(updatedTodo);
    } else {
      res.status(404).json({ error: "Article not found" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json(err.message);
  }
});

// Delete a news article
app.delete("/todo/:id", async (req, res) => {
  try {
    const id = req.params.id;
    const removedTodo = await Todofile.findByIdAndRemove(id);
    if (removedTodo) {
      res.json({ message: "Article deleted successfully" });
    } else {
      res.status(404).json({ error: "Article not found" });
    }
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Failed to delete article" });
  }
});

// Start the server
app.listen(3001, () => {
  console.log("Server started on port 3001");
});
